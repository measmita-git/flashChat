package boi.walle.modal_progress_hud_nsn_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
