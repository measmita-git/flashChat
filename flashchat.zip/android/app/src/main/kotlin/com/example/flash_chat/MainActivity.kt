package com.example.flash_chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
